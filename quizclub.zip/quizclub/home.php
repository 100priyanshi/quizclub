<?php include 'db_connect.php' ?>
<style>
   span.float-right.summary_icon {
    font-size: 3rem;
    position: absolute;
    right: 1rem;
    color: #ffffff96;
}
</style>

<div class="containe-fluid">
   <!--  <div class="row mt-3 mb-3 pl-5 pr-5">
        <div class="col-md-4 offset-md-2">
            <div class="card bg-warning">
                <div class="card-body text-white">
                    <span class="float-right summary_icon"><i class="fa fa-car"></i></span>
                    <h4><b>
                    </b></h4>
                    <p><b>Total Parked Vehicle</b></p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success">
                <div class="card-body text-white">
                    <span class="float-right summary_icon"><i class="fa fa-car"></i></span>
                    <h4><b>

                    </b></h4>
                    <p><b>Total Checked-Out Vehicle</b></p>
                </div>
            </div>
        </div>
    </div> -->

	<div class="row mt-3 ml-3 mr-3">
			<div class="col-lg-12">
    			<div class="card">
    				<div class="card-body">
    				<?php echo "Welcome back ". $_SESSION['login_name']."!"
                      ?>
    					<hr>	

                        <div class="row">
                            
                        </div>      			
    				</div>
    				
    				
    		      </div>
                </div>
	</div>
<hr>



</div>
<script>
	
</script>